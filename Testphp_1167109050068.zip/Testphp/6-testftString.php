<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passing Argument by Reference</title>
</head>
<body>
    <h2>First time for PHP</h2>
    <?php
        function sayHello($parem = NULL){
            echo "Hello Com Sci <br/>";
    }
       $function_holder = "sayHello";
       $function_holder();
       sayHello();
    ?>
</body>
</html>