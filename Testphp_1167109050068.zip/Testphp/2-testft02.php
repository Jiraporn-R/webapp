<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weiting PHP Function</title>
</head>
<body>
    <h2>First time for PHP</h2>
    <?php
        function addFunction($num1,$num2){
            $sum = $num1 + $num2;
            echo "Sum of the two number is : $sum";
    }

    addFunction(10,20);
    ?>
</body>
</html>