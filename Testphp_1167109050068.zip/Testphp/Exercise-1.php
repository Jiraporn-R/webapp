<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ex1</title>
</head>
<body>
    <h2>Exercise-1</h2>
    <?php
    function test($str){
        $s = substr($str, strlen($str) -1);
        return $s.$str.$s;
    }

    echo test("Red")." <br/> \n";

    echo test("Green")."<br/> \n";
    echo test("1")."<br/> \n";
    ?>
</body>
</html>